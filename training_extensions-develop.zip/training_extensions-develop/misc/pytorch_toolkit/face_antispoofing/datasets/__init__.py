from .casia_surf import CasiaSurfDataset
from .celeba_spoof import CelebASpoofDataset
from .lcc_fasd import LccFasdDataset
from .database import get_datasets
