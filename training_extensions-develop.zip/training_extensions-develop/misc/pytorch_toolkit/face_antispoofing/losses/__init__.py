from .am_softmax import AMSoftmaxLoss, AngleSimpleLinear
from .soft_triple import SoftTripleLinear, SoftTripleLoss
